Ocarina of Time Story Co-op (Linux)
===================================

Play the whole of Ocarina of Time with friends: one shared story, one team save, and you time travel together.
Built on Ship of Harkinian (HarbourMasters) and ShipwrightOnline (lukegrahamSydney).
Project page: https://github.com/cranebeaker/ocarina-coop

You need your own supported Ocarina of Time ROM. No game files are included.

Requirements
------------
64-bit Linux, built on Ubuntu 24.04 (needs a similarly recent distro: glibc 2.39 or newer), a GPU with OpenGL, and
these libraries (Ubuntu/Debian package names):
  sudo apt install libsdl2-2.0-0 libsdl2-net-2.0-0 libzip4t64 libtinyxml2-10 libspdlog1.12 libfmt9 libpng16-16 \
       libopusfile0 libvorbisfile3 libogg0 libopengl0
The Steam client must be installed, running and logged in to use the Steam play mode.

First start
-----------
1. Run ./soh.elf once. When it asks for your ROM, pick it (or put the .z64 file in this folder first).
   The game builds oot.o2r from it; this takes a minute and only happens once.
2. Close the game.

Play over Steam (no IP addresses, no port forwarding; Steam must be running)
------------------------------------------------------------------------------
Host:  ./"Host over Steam.sh"  starts the server, opens a friends-only Steam lobby and your game.
Join:  ./"Join over Steam.sh"  finds a friend who is hosting and starts your game connected to them.
       With it open, right-click your friend in Steam and Join Game works too.
Then the host opens the online window, creates a party with "Story Co-op" turned on, and invites everyone.
Press Q in the terminal (or Ctrl+C) to stop; the server saves the team progress when it stops.

Play by address instead
-----------------------
Run ./server/OOTServer (port 21050) and connect from the online window in the game.

Files
-----
soh.elf, soh.o2r, assets/          the game (Ship of Harkinian with ShipwrightOnline and Story Co-op)
server/OOTServer, config.json      the server; team saves go to server/data/story
OOTSteamLink, libsteam_api.so      the Steam relay helper (Valve's free "Spacewar" app, AppID 480)
